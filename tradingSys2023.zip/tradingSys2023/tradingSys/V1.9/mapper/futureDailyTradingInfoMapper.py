# -*- coding:utf-8 -*-
import sys
import os
# 把当前文件所在文件夹的父文件夹路径加入到PYTHONPATH
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils import mongoUtils as mu


# 每日套利交易信息表
# future_daily_trading_info_set

def init():
    mongod_con = mu.db_connection("future_daily_trading_info_set")
    return mongod_con

def find_all_from_mongodb(condition):
    mongod_con = init()
    
    # """ query info from mongodb """
    date_cursor = mongod_con.find(condition)
    arr = []
    for x in date_cursor:
        # 将每条数据添加到数组中
        arr.append(x)
    return arr
    

def find_one_from_mongodb(condition):
    mongod_con = init()
    
    """ query info from mongodb """
    x = mongod_con.find_one(condition)
    return x

def insert_one_to_mongodb(data):
    mongod_con = init()
    
    """ save info to mongodb """
    x = mongod_con.insert_one(data)


def batch_insert_to_mongodb(dataList):
    mongod_con = init()
    
    """ save info to mongodb """
    for each_item in dataList:
        x = mongod_con.insert_one(each_item)


def update_to_mongodb(condition,data):
    mongod_con = init()
    
    """ update info to mongodb """
    x = mongod_con.update(condition,{"$set":data})


def update_many_to_mongodb(condition,data):
    mongod_con = init()

    """ update info to mongodb """
    x = mongod_con.update_many(condition,{"$set":data})


# dataList = [{"tradingDay":"2022-10-25","productName":"沪铅test","productCode":"PB",
#                 "cashPrice":"200","lastPrice":"150","futureBasis":"50",
#                 "spread":"10","ratio":"5"}]
# save_to_mongodb(dataList)

# condition = {"tradingDay":"2022-10-25","productCode":"PB"}
# data = {"futureBasisRatio":"2.55"}
# update_to_mongodb(condition,data)

# data = {"isValid":"Y"}
# update_many_to_mongodb({},data)

# list = comUtils.productNameAndCodeList
# # list = [{'productName': '棕榈', 'productCode': 'P'}]
# for pro in list:
#     #查詢當前品種旺季合約
#     condition = {}
#     condition['productName'] = pro['productName']
#     baseInfoDic = dailyBaseInfo.find_one_from_mongodb(condition)
#
#     try:
#         hotMonths = baseInfoDic['hotMonth']
#
#         #查詢交易記錄信息
#         conditionTrade = {}
#         conditionTrade['productCode'] = pro['productCode']
#         conditionTrade['mon1'] = "03"
#         retDailyRraDataList = dailyTraInfo.find_all_from_mongodb(conditionTrade)
#
#         if hotMonths != None:
#             for retDailyRraData in retDailyRraDataList:
#                 if 2 in hotMonths:
#                     hotMonthFlag = 'W'
#                 else:
#                     hotMonthFlag = '-'
#                 upddata = {}
#                 upddata['hotMonthFlag'] = hotMonthFlag
#
#                 updcon = {}
#                 updcon['productCode'] = retDailyRraData['productCode']
#                 updcon['tradingDay'] = retDailyRraData['tradingDay']
#                 updcon['mon1'] = retDailyRraData['mon1']
#                 dailyTraInfo.update_to_mongodb(updcon,upddata)
#     except Exception as e:
#         errorMsg = '品种：' + pro['productName'] + '，系统异常！' + str(e)
#         print(errorMsg)
#         continue