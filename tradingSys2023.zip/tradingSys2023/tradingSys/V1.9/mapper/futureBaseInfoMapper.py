# -*- coding:utf-8 -*-
import sys
import os
# 把当前文件所在文件夹的父文件夹路径加入到PYTHONPATH
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils import mongoUtils as mu


# 期货品种基本信息表
# future_base_info_set

def init():
    mongod_con = mu.db_connection("future_base_info_set")
    return mongod_con


def find_one_from_mongodb(condition):
    mongod_con = init()

    """ query info from mongodb """
    x = mongod_con.find_one(condition)
    return x


def batch_insert_to_mongodb(dataList):
    mongod_con = init()

    """ save info to mongodb """
    for each_item in dataList:
        x = mongod_con.insert_one(each_item)


def insert_one_to_mongodb(data):
    mongod_con = init()

    """ save info to mongodb """
    x = mongod_con.insert_one(data)


def update_to_mongodb(condition, data):
    mongod_con = init()

    """ update info to mongodb """
    x = mongod_con.update(condition, {"$set": data})


list = [{'productName': '沪铜002', 'productCode': 'CU002'}]
# list = comUtils.productNameAndCodeList
for data in list:
    con = {}
    con['productName'] = data['productName']
    ret = find_one_from_mongodb(con)
    if ret == None:
        insert_one_to_mongodb(data)

#
# lists = [
#     ["沥青","7,8,9,10"],
#     ["纸浆","3,4,5,6,9,10,11,12"],
#     ["纯碱","10"],
#     ["玻璃","4,5,6,7,8,9,"],
#     ["苯乙烯","8,9,10"],
#     ["尿素","3,4,5,6,7,8,9,10"],
#     ["橡胶","1,3,5,8,9,10"],
#     ["燃油","1,3,4,5,10,11"],
#     ["甲醇","7,8,9,10"],
#     ["PVC","3,4,5,10,11"],
#     ["短纤","3,4,5,8,9,10"],
#     ["PTA","1,2,6,7,8,12"],
#     ["液化石油气","10,11,12"],
#     ["豆一","3,5,6,7,8,"],
#     ["豆二","3,5,6,7,8,"],
#     ["花生","1"],
#     ["豆粕","4,5,6,7,8,9"],
#     ["豆油","1,4,5,11,12"],
#     ["棕榈","6,7,8,9"],
#     ["菜粕","3,8,9,10"],
#     ["菜油","1,2,3,9,10,11,12"],
#     ["白糖","1,7,8,10,11"],
#     ["棉花","3,4,9,10,11"],
#     ["鸡蛋","1,4,5,6,9,10"],
#     ["生猪","1,5,6,7,8,11"],
#     ["玉米","1,4,5,11,12"],
#     ["苹果","4,5,6,7"],
#     ["红枣","1,2,3,10,11"]








#     ["焦煤","1,2,8,9"]
#     ["焦炭","1,4,5,8,11,12"]
#     ["铁矿石","1,2,7,8,11,12"]
#     ["螺纹","3,4,7,8,11,12"]
#     ["热卷","4,5,6,7,8,9"]
# ]
# # list = comUtils.productNameAndCodeList
# for list in lists:
#     con = {}
#     con['productName'] = list[0]
#
#     data = {}
#     data['hotMonth'] = list[1].split(",")
#     ret = update_to_mongodb(con, data)
#     print(list[0]+" ret:",ret)
