# -*- coding:utf-8 -*-
import sys
import os
# 把当前文件所在文件夹的父文件夹路径加入到PYTHONPATH
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import calendar
import datetime
import time
import schedule
import chinese_calendar
import traceback

from mapper import futureDailyTradingInfoMapper as dailyTraInfo, futureBaseInfoMapper as dailyBaseInfo, \
    futureTradingPoolMapper as tradingPool, futureDailyStructureMapper as dailyStruc, \
    futureEmailRecordMapper as emailRecord
from utils import comUtils as comUtils, emailUtils as emailUtils, fileUtils as fileUtils


def job(productNameList, mon1, mon2):
    print("Testing......")

    # # 获取当天日期yyyy-MM-dd
    # nowDate = datetime.datetime.now()
    # today = nowDate.strftime("%Y-%m-%d")
    # print("today: ", today)
    # tradingDayList = []
    # tradingDayList.append(today)

    tradingDayList = ['2023-03-21']

    productExcludeList = comUtils.productExcludeList
    # 获取工作日
    today = datetime.datetime.today()
    year = today.year
    month = today.month
    max_day = calendar.monthrange(year, month)[1]
    work_days = chinese_calendar.get_workdays(datetime.datetime(year, month, 1),
                                              datetime.datetime(year, month, max_day))
    print('*****************************************************************')
    print('近月：', mon1)
    print('远月：', mon2)
    print('品种：', productNameList)
    print('*****************************************************************')

    for tradingDay in tradingDayList:
        # 当日为非交易日，跳过
        tradingDayDate = datetime.date(*map(int, tradingDay.split('-')))
        if tradingDayDate not in work_days:
            print(tradingDay + "为非交易日，跳过")
            continue

        print('*****************************************************************')
        print('日期：', tradingDay)

        # 1、先通过日期从库里查，查不到，再【重新通过指定日期，获取所有品种现货价格】
        dailyTraCondition = {}
        dailyTraCondition['tradingDay'] = tradingDay
        dailyTraCondition['mon1'] = mon1
        dailyTraCondition['mon2'] = mon2
        retDailyRraDataList = dailyTraInfo.find_all_from_mongodb(dailyTraCondition)

        print('-----------------------------------------------------------------')
        print('品种' + '\t\t期限结构' + '\t\t斜率' + '\t\t基差趋势' + '\t\t基差率' + '\t\t盈亏比' + '\t\t近月基差' + '\t\t价差')
        print('-----------------------------------------------------------------')

        # 邮件打印头
        emailStr = '品种' + '\t\t期限结构' + '\t\t斜率' + '\t\t基差趋势' + '\t\t基差率' + '\t\t盈亏比' + '\t\t近月基差' + '\t\t价差' + '\n'

        if (len(retDailyRraDataList) < 50):
            print('重新通过日期: ' + tradingDay + '，获取所有品种现货价格')
            productListJYFM = comUtils.getCashPriceByJYFM(tradingDay)
            print('productListJYFM: ', productListJYFM)
            productListSYS = comUtils.getCashPriceBySYS(tradingDay, productListJYFM)
            print('productListSYS: ', productListSYS)
            productMapList = productListJYFM + productListSYS
            errorMsgList = []

            # 批量获取指定品种的基差
            insertRet = comUtils.getBasisBySYS(tradingDay, comUtils.selectList)
            # print("insertRet",insertRet)

            productNameList = ['铜']
            for productName in productNameList:
                try:
                    # 品种如果在排除名单内，则跳过
                    if (productName in productExcludeList):
                        print(productName,"在排除名单内，则跳过")
                        continue

                    # 从现货价格结果集中，通过品种名称，获取现货价格
                    cashPrice = comUtils.getCashPriceByName(productName, productMapList)
                    # print("cashPrice",cashPrice)
                    if cashPrice == '':
                        errorMsg = '品种：' + productName + '，通过品种名称，获取现货价格，查询异常！'
                        errorMsgList.append(errorMsg)
                        continue

                    # 获取品种编码
                    condition = {}
                    condition['productName'] = productName
                    baseInfoDic = dailyBaseInfo.find_one_from_mongodb(condition)
                    # print(productName," baseInfoDic:",baseInfoDic)

                    productCode = baseInfoDic['productCode']

                    try:
                        hotMonths = baseInfoDic['hotMonth']
                        mon1Sin = mon1.replace("0","")
                        if mon1Sin in hotMonths:
                            hotMonthFlag = 'W'
                        else:
                            hotMonthFlag = '-'

                    except Exception as e:
                        # errorMsg = '品种：' + productName + '，獲取旺季月份，系统异常！' + str(e)
                        hotMonthFlag = '-'


                    # 获取基差趋势
                    basisStru = comUtils.getBasisByTypeAndTradingDay(productCode, tradingDay)
                    # print("basisStru",basisStru)

                    # 获取仓单趋势
                    # warehouse = comUtils.getWarehouseByTypeAndTradingDay(productCode, tradingDay)
                    # print("warehouse",warehouse)

                    # 先通过编码和日期从库里查，查不到，再【重新查询当日期限结构】并落库
                    strucQueryCondition = {'productCode': productCode, 'tradingDay': tradingDay}
                    retStrucData = dailyStruc.find_one_from_mongodb(strucQueryCondition)

                    if (retStrucData == None):
                        print('重新查询: ' + productName + '当日期限结构并落库')
                        retStrucData = comUtils.getStructureByJYFM(productCode, tradingDay)
                        # print("retStrucData",retStrucData)

                    structure = retStrucData['structure']
                    slope = retStrucData['slope']

                    # 获取近远月价差
                    retDic = {}
                    try:
                        retDic = comUtils.getDailyFutureSpread(tradingDay, productCode, mon1, productCode, mon2)
                        # print("retDic",retDic)

                    except Exception as e:
                        errorMsg = '品种：' + productName + '，获取近远月价差，接口异常！' + str(e)
                        traceback.print_exc(e)
                        print(e)
                        errorMsgList.append(errorMsg)
                        continue

                    # 计算盈亏比
                    spread = retDic['spread']
                    lastPrice = retDic['lastPrice']
                    futureBasis = float(cashPrice) - lastPrice
                    ratio = format(futureBasis / spread, '.2f')
                    cashPriceFloat = float(cashPrice)

                    # 计算近月基差率
                    futureBasisRatio = format((futureBasis * 100) / cashPriceFloat, '.2f')

                    ############################################################################
                    # 所有盈亏比数据，落库到【每日套利交易信息表】
                    resultInfo = {}
                    resultInfo['productName'] = productName
                    resultInfo['productCode'] = productCode
                    resultInfo['structure'] = structure
                    #resultInfo['warehouse'] = warehouse
                    resultInfo['slope'] = slope
                    resultInfo['basisStru'] = basisStru
                    resultInfo['ratio'] = float(ratio)
                    resultInfo['tradingDay'] = tradingDay
                    resultInfo['futureBasisRatio'] = float(futureBasisRatio)
                    resultInfo['mon1'] = mon1
                    resultInfo['mon2'] = mon2
                    resultInfo['cashPrice'] = str(cashPrice)
                    resultInfo['lastPrice'] = str(lastPrice)
                    resultInfo['futureBasis'] = format(futureBasis, '.1f')
                    resultInfo['spread'] = str(spread)

                    # 季節淡旺季标识
                    resultInfo['hotMonthFlag'] = hotMonthFlag
                    resultInfo['isValid'] = 'Y'

                    condition = {}
                    condition['tradingDay'] = tradingDay
                    condition['productCode'] = productCode
                    condition['mon1'] = mon1
                    retDailyTraData = dailyTraInfo.find_one_from_mongodb(condition)
                    if (retDailyTraData == None):
                        # print('保存品种: ' + productName + '=====》每日套利交易表')
                        dailyTraInfo.insert_one_to_mongodb(resultInfo)
                    else:
                        dailyTraInfo.update_to_mongodb(condition,resultInfo)

                    resultInfoStr = resultInfo['productName'] + '\t\t' + \
                                    resultInfo['structure'] + '\t\t' + \
                                    str(resultInfo['slope']) + '\t\t' + \
                                    str(resultInfo['basisStru']) + '\t\t' + \
                                    str(resultInfo['futureBasisRatio']) + '% \t\t' + \
                                    str(resultInfo['ratio']) + '\t\t' + \
                                    resultInfo['futureBasis'] + '\t\t' + \
                                    resultInfo['spread']
                    print(resultInfoStr)
                    emailStr = emailStr + resultInfoStr + '\n'

                    ############################################################################
                    dailyPoolSave(resultInfo)
                    ############################################################################

                except Exception as e:

                    errorMsg = '品种：' + productName + '，系统异常！' + str(e)
                    errorMsgList.append(errorMsg)
                    continue

            print('------------------------------errorMsgList-----------------------')
            for msg in errorMsgList:
                print(msg)

        else:
            print('当日套利信息已存在！')
            for dailyTraData in retDailyRraDataList:
                dailyTraDataStr = dailyTraData['productName'] + '\t\t' + \
                                  dailyTraData['structure'] + '\t\t' + \
                                  str(dailyTraData['slope']) + '\t\t' + \
                                  str(dailyTraData['basisStru']) + '\t\t' + \
                                  str(dailyTraData['futureBasisRatio']) + '% \t\t' + \
                                  str(dailyTraData['ratio']) + '\t\t' + \
                                  dailyTraData['futureBasis'] + '\t\t' + \
                                  dailyTraData['spread']
                print(dailyTraDataStr)

                # 可交易品种数据，落库到【期货交易待选品种表 】
                dailyPoolSave(dailyTraData)

                emailStr = emailStr + dailyTraDataStr + '\n'

        # 邮件发送功能
        sendEmail(emailStr, mon1, mon2, tradingDay)

    print('*************************************\t结束\t*********************')

def dailyPoolSave(resultInfo):
    productCode = resultInfo['productCode']
    productName = resultInfo['productName']
    mon1 = resultInfo['mon1']
    mon2 = resultInfo['mon2']
    tradingDay = resultInfo['tradingDay']
    structure = resultInfo['structure']
    slope = resultInfo['slope']
    futureBasisRatio = resultInfo['futureBasisRatio']
    ratio = resultInfo['ratio']

    # 1、先通过productCode mon1 mon2查询当前品种 是否在交易池中，
    preCondition = {}
    preCondition['productCode'] = productCode
    preCondition['mon1'] = mon1
    preCondition['mon2'] = mon2
    preCondition['isValid'] = 'Y'
    retPreData = tradingPool.find_one_from_mongodb(preCondition)

    orgCondition = {}
    orgCondition['productCode'] = productCode
    orgCondition['mon1'] = mon1
    orgCondition['mon2'] = mon2
    orgCondition['tradingDay'] = tradingDay
    orgCondition['isValid'] = 'Y'
    retOrgData = tradingPool.find_one_from_mongodb(orgCondition)

    # 2、不存在，并且满足交易条件，则直接插入
    if (retPreData == None):
        # if (structure == 'BACK' and slope > 0.02 and float(futureBasisRatio) > 4 and float(ratio) > 2):
        if (structure == 'BACK'):
            print(productName + '不存在，满足交易条件' + '=====》【品种交易池】')
            if (retOrgData == None):
                tradingPool.insert_one_to_mongodb(resultInfo)

    # 3、存在，跟踪近月基差率
    else:
        # 【基差率>4%,期限结构为BACK,盈亏比>0.5】则直接插入
        # if (float(futureBasisRatio) >= 4 and structure == 'BACK' and float(ratio) > 0.5):
        if (structure == 'BACK'):
            print(productName + '存在，跟踪期限结构，新增' + '=====》【品种交易池】')
            if (retOrgData == None):
                tradingPool.insert_one_to_mongodb(resultInfo)
        # 基差率<1%,则软删除configuration
        else:
            print(productName + '存在，期限结构，删除' + '《=====【品种交易池】')
            updCondition = {}
            updCondition['productCode'] = productCode
            updCondition['mon1'] = mon1
            updCondition['mon2'] = mon2
            data = {}
            data['isValid'] = 'N'
            tradingPool.update_many_to_mongodb(updCondition, data)


def sendEmail(emailStr, mon1, mon2, tradingDay):
    tradingPoolLine = '----------------------------------'+tradingDay+'最新可交易品种-----------------------'
    print(tradingPoolLine)
    emailStr = emailStr + tradingPoolLine + '\n'
    poolCon = {}
    poolCon['tradingDay'] = tradingDay
    poolCon['mon1'] = mon1
    poolCon['isValid'] = 'Y'
    poolListData = tradingPool.find_from_mongodb_with_condition(poolCon, "tradingDay")
    for pool in poolListData:
        #if pool['basisStru'] == 'UP':
        poolInfo = pool['productName'] + '\t\t' + \
                   pool['structure'] + '\t\t' + \
                   str(pool['slope']) + '\t\t' + \
                   str(pool['basisStru']) + '\t\t' + \
                   str(pool['futureBasisRatio']) + '%\t\t' + \
                   str(pool['ratio']) + '\t\t' + \
                   pool['futureBasis'] + '\t\t' + \
                   pool['spread']
        # pool['mon1'] + '\t\t' + \
        # pool['mon2'] + '\t\t' + \
        # pool['tradingDay']
        print(poolInfo)
        emailStr = emailStr + poolInfo + '\n'
    # 查询当日当套利组合，是否已经发过邮件
    emailCondition = {}
    emailCondition['tradingDay'] = tradingDay
    emailCondition['mon1'] = mon1
    emailCondition['mon2'] = mon2
    retEmailRecordData = emailRecord.find_one_from_mongodb(emailCondition)
    if (retEmailRecordData == None):
        # 写文件
        log_file = open('utils/data.txt', 'w+')
        fileUtils.write(log_file, emailStr)
        log_file.close()

        # 邮件附件通知结果
        subject = '期货套利分析【' + tradingDay + '|' + mon1 + '|' + mon2 + '】'
        content = '请查看附件！'
        mail = emailUtils.makeAttrMail(subject, content)
        attachment = emailUtils.makeAttachment('utils/data.txt')
        mail.attach(attachment)
        emailUtils.sendMail(mail)
        print('发送邮件成功')
        emailRecordData = {}
        emailRecordData['tradingDay'] = tradingDay
        emailRecordData['mon1'] = mon1
        emailRecordData['mon2'] = mon2
        emailRecordData['isSendFlag'] = 'Y'
        emailRecord.insert_one_to_mongodb(emailRecordData)
    else:
        print('当日邮件已发送')


if __name__ == '__main__':
    productNameList = comUtils.productNameList

    mon_01 = '01'
    mon_02 = '02'
    mon_03 = '03'
    mon_04 = '04'
    mon_05 = '05'
    mon_06 = '06'
    mon_07 = '07'

    job(productNameList, mon_05, mon_07)

    # tradingDayList = ["2023-02-20"]
    # setTime = "19:00"
    # schedule.every().day.at(setTime).do(job, productNameList, mon_05, mon_07)

    # while True:
    #     print(time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time()))+" schedule.run_pending:",setTime)
    #     schedule.run_pending()
    #     time.sleep(1*60*10)

