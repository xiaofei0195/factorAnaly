import numpy as np
# a = numpy.array([[1,2,3],[4,5,6],[7,8,9]])
# data1 = numpy.amin(a)
# print('data1:',data1)
#
# data2 = numpy.amax(a)
# print('data2:',data2)

import pandas as pd
# s = pd.Series([1,3,5,np.nan,8])
# print(s)
# index = s.index
# print('index:',index)

dates = pd.date_range('20130101',periods=6)
print(dates)
df = pd.DataFrame(np.random.randn(6,4),index=dates,columns=list('ABCD'))
print(df)