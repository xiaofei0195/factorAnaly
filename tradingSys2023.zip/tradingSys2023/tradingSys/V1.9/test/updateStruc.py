from utils.old import comUtils as cm

structure = cm.getStructure()
print('structure: ',structure)