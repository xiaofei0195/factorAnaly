import chinese_calendar
import datetime

def test1():
    work_days = chinese_calendar.get_workdays(datetime.datetime(2022,12,1), datetime.datetime(2022,12,31))

    for work_day in work_days:
        print(work_day)

if __name__=='__main__':
    test1()
