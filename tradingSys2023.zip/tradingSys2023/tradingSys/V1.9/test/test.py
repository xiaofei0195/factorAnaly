# coding=utf-8
from __future__ import print_function, absolute_import
from gm.api import *
import sys
try:
    import talib
except:
    print(r'请安装talib，可以到 https://www.lfd.uci.edu/~gohlke/pythonlibs/#ta-lib 下载对应talib的whl文件安装')
    sys.exit(-1)

def init(context):
    context.short = 20                                             # 短周期均线
    context.long = 60                                              # 长周期均线
    context.symbol = 'SHFE.RB'                                     # 订阅交易标的
    context.period = context.long + 1                              # 订阅数据滑窗长度
    subscribe(context.symbol, '60s', count=context.period)         # 订阅行情


def on_bar(context, bars):
    # 获取通过subscribe订阅的数据
    prices = context.data(context.symbol, '60s', context.period, fields='close')

    # 利用talib库计算长短周期均线
    short_avg = talib.SMA(prices.values.reshape(context.period), context.short)
    long_avg = talib.SMA(prices.values.reshape(context.period), context.long)


if __name__ == '__main__':
    '''
        strategy_id策略ID,由系统生成
        filename文件名,请与本文件名保持一致
        mode实时模式:MODE_LIVE回测模式:MODE_BACKTEST
        token绑定计算机的ID,可在系统设置-密钥管理中生成
        backtest_start_time回测开始时间
        backtest_end_time回测结束时间
        backtest_adjust股票复权方式不复权:ADJUST_NONE前复权:ADJUST_PREV后复权:ADJUST_POST
        backtest_initial_cash回测初始资金
        backtest_commission_ratio回测佣金比例
        backtest_slippage_ratio回测滑点比例
    '''
    run(strategy_id='strategy_id',
        filename='../main.py',
        mode=MODE_BACKTEST,
        token='{{db3fefbe888684f75e4457e9d40ed84e968bfcb4}}',
        backtest_start_time='2021-01-01 09:00:00',
        backtest_end_time='2021-06-30 15:00:00',
        backtest_adjust=ADJUST_PREV,
        backtest_initial_cash=100000,
        backtest_commission_ratio=0.0001,
        backtest_slippage_ratio=0.0001)
