# coding=utf-8
# from __future__ import print_function, absolute_import, unicode_literals
# import numpy as np
# import pandas as pd
# from gm.api import *
# # 可以直接提取数据，掘金终端需要打开，接口取数是通过网络请求的方式，效率一般，行情数据可通过subscribe订阅方式
# # 设置token， 查看已有token ID,在用户-密钥管理里获取
# set_token('db3fefbe888684f75e4457e9d40ed84e968bfcb4')
#
# # 查询历史行情, 采用定点复权的方式， adjust指定前复权，adjust_end_time指定复权时间点
# data_m2212 = history(symbol='DCE.m2212', frequency='1800s', start_time='2022-11-07 09:00:00', end_time='2022-11-08 16:00:00',
#                fields='open,high,low,close', adjust=ADJUST_PREV, adjust_end_time='2022-11-08', df=True)
# data_m2301 = history(symbol='DCE.m2301', frequency='1800s', start_time='2022-11-07 09:00:00', end_time='2022-11-08 16:00:00',
#                fields='open,high,low,close', adjust=ADJUST_PREV, adjust_end_time='2022-11-08', df=True)
# print(data_m2212)
# print(data_m2301)
# print(data_m2212.index)
# print(data_m2212.columns)
# print(data_m2212.values)
# print(data_m2212.loc[0,'open'])
# print(data_m2212.loc[0,'high'])
# print(data_m2212.loc[0,'low'])
# print(data_m2212.loc[0,'close'])

# series0 = data_m2212.iloc[0,:]
# series0ValueOpen = series0['open']
# print(series0)
# print(series0ValueOpen)

#
# def dealSeg(row_m2212_m2301,segName):
#     valMon1 = getattr(rowMon1, segName)
#     valMon2 = getattr(rowMon2, segName)
#     valMonBet = valMon1 - valMon2
#     row_m2212_m2301[segName] = valMonBet
#     return row_m2212_m2301

#计算M2212-M2301合约价差
#1、遍历dataframe
# data_m2212_m2301 = []
# for indexMon1,rowMon1 in data_m2212.iterrows():
#     for indexMon2,rowMon2 in data_m2301.iterrows():
#
#         if(indexMon1 == indexMon2):
#             # print('indexMon1:',indexMon1)
#             # print('indexMon2:',indexMon2)
#
#             row_m2212_m2301 = {}
#             #处理open字段
#             dealSeg(row_m2212_m2301,'open')
#             dealSeg(row_m2212_m2301,'high')
#             dealSeg(row_m2212_m2301,'low')
#             dealSeg(row_m2212_m2301,'close')
#
#             data_m2212_m2301.append(row_m2212_m2301)
#             # print('row_m2212_m2301:',row_m2212_m2301)
#
# print('data_m2212_m2301:\n',data_m2212_m2301)
# dataFrame = pd.DataFrame(data_m2212_m2301)
# print(dataFrame)



# def init(context):
#     context.goods = ['DCE.m2212', 'DCE.m2303']
#     # 订阅品种数据
#     subscribe(symbols = context.goods,frequency = '1d',count = 31,wait_group = True)
# def on_bar(context, bars):
#     # 获取历史数据
#     close_2212 = context.data(symbol=context.goods[0], frequency='1d', count=31, fields='close')['close'].values
#     # close_2303 = context.data(symbol=context.goods[1], frequency='1d', count=31, fields='close')['close'].values
#     print('close_2212: ',close_2212)
#     # print('close_2303: ',close_2303)
#
# if __name__ == '__main__':
#     '''
#     strategy_id策略ID,由系统生成
#     filename文件名,请与本文件名保持一致
#     mode实时模式:MODE_LIVE回测模式:MODE_BACKTEST
#     token绑定计算机的ID,可在系统设置-密钥管理中生成
#     backtest_start_time回测开始时间
#     backtest_end_time回测结束时间
#     backtest_adjust股票复权方式不复权:ADJUST_NONE前复权:ADJUST_PREV后复权:ADJUST_POST
#     backtest_initial_cash回测初始资金
#     backtest_commission_ratio回测佣金比例
#     backtest_slippage_ratio回测滑点比例
#     '''
#     run(strategy_id='strategy_id',
#         filename='main.py',
#         mode=MODE_BACKTEST,
#         token='ed08bb40271747d4ccd3d6ab309169759c7fc419',
#         backtest_start_time='2022-10-01 08:00:00',
#         backtest_end_time='2022-11-08 16:00:00',
#         backtest_adjust=ADJUST_PREV,
#         backtest_initial_cash=2000000,
#         backtest_commission_ratio=0.0001,
#         backtest_slippage_ratio=0.0001)
