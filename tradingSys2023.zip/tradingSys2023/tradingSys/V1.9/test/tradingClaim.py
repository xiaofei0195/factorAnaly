import requests
import json
from bs4 import BeautifulSoup   # 一个解析库，用来解析网页结构

#查询现货价格（通过生意社期货现表）
def getCashPriceBySYS(tradingDay):
    r = requests.get('http://www.100ppi.com/sf/day-' + tradingDay + '.html')
    retData = r.text

    bs = BeautifulSoup(retData, "html.parser")   # 解析网页
    table = bs.find_all("tr") # 定位信息

    productList = []    #[{品种名称，现货价格},{}]结果集
    for i in range(len(table)):
        productDic = {}  #{品种名称，现货价格}

        trStr = table[i].text.strip()
        if len(trStr) > 50 and not trStr.startswith('http'):
            trList = trStr.split('\n')
            trNewList = []
            for td in trList:
                tdNew = td.replace('\xa0','')
                trNewList.append(tdNew)
            productName = trNewList[0]
            cashPrice = trNewList[1]

            productDic['productName'] = productName
            productDic['cashPrice'] = cashPrice
            productList.append(productDic)
    print('productList：', productList)

getCashPriceBySYS('2022-10-20')