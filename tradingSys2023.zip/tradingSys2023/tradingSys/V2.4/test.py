# -*- coding:utf-8 -*-
import calendar
import datetime
import sys
import os
# 把当前文件所在文件夹的父文件夹路径加入到PYTHONPATH
import time

import chinese_calendar
import schedule

from utils.handle import dataCleanUtils, getTempUtils, dataCalUtils, dateUtils

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from mapper.clean import baseInfoMapper as baseMp
from mapper import tradingInfoDailyMapper as tradingInfoDailyMp


def job():
    tradingDayList = []
    #获取当前日期字符串
    curTradingDay = time.strftime('%Y-%m-%d',time.localtime(time.time()))
    tradingDayList.append(curTradingDay)
    print('tradingDayList:', tradingDayList)

    # 获取工作日
    today = datetime.datetime.today()
    year = today.year
    month = today.month
    max_day = calendar.monthrange(year, month)[1]
    work_days = chinese_calendar.get_workdays(datetime.datetime(year, month, 1),
                                              datetime.datetime(year, month, max_day))

    mon1 = '06'
    mon2 = '09'
    shiftDays = 10
    # 从基本信息库中，查询所有品种编码和名称
    baseCon = {}
    # baseCon['productCode'] = 'I'
    retBaseList = baseMp.find_all_from_mongodb(baseCon)

    #06
    inValidMonProLlist = ['豆一','豆油','菜油','豆粕','菜粕','玉米','淀粉','棉花','油菜籽','生猪']

    for tradingDay in tradingDayList:

        # 当日为非交易日，跳过
        tradingDayDate = datetime.date(*map(int, tradingDay.split('-')))
        if tradingDayDate not in work_days:
            print(tradingDay + "为非交易日，跳过")
            continue

        print('*****************************************************************')
        print('日期：', tradingDay)

        #################
        # 获取当日前15天的现货数据
        #################
        # 不存在，则重新查询
        # 存在，则跳过
        print('获取【' + tradingDay + '】前15天现货数据')
        dayRange = dateUtils.getTradingDayList(tradingDay, shiftDays)
        if '2023-04-23' in dayRange:
            dayRange.remove('2023-04-23')

        print('dayRange:', dayRange)
        for day in dayRange:
            retCashList = getTempUtils.getCashPrice(day)
            if retCashList == None:
                print(retCashList)
                continue

        #################
        # 获取当日前15天的价差数据，并清洗到价差目标表
        #################
        # 不存在，则重新查询
        # 存在，则跳过
        print('获取【' + tradingDay + '】前15天价差数据')
        for day in dayRange:
            for baseInfo in retBaseList:
                retSpreadTemp = getTempUtils.getSpreadDailyTemp(baseInfo, day, mon1, mon2)
                if retSpreadTemp == None:
                    continue
                if baseInfo['productName'] not in inValidMonProLlist:
                    dataCleanUtils.cleanToSpreadDaily(baseInfo, day, mon1, mon2, dayRange, 'N')

        #################
        # 数据暂存到TEMP表
        #################
        print('数据暂存到TEMP表')
        errorList = []
        for baseInfo in retBaseList:
            priceTemp = getTempUtils.getPriceStruDailyTemp(baseInfo, tradingDay)
            if priceTemp == None:
                errorList.append(baseInfo['productCode'])
                continue
            basisTemp = getTempUtils.getBasisDailyTemp(baseInfo, tradingDay)
            if basisTemp == None:
                errorList.append(['productCode'])
                continue
            spreadTemp = getTempUtils.getSpreadDailyTemp(baseInfo, tradingDay, mon1, mon2)
            if spreadTemp == None:
                errorList.append(['productCode'])
                continue

        #################
        # 数据清洗到目标表
        #################
        print('数据清洗到目标表')
        for baseInfo in retBaseList:
            if baseInfo['productCode'] in errorList:
                print('品种' + baseInfo['productCode'] + '异常，跳过清洗')
                continue

            tradingInfo = {}
            tradingInfo['productName'] = baseInfo['productName']
            tradingInfo['productCode'] = baseInfo['productCode']
            tradingInfo['tradingDay'] = tradingDay

            # 【期限结构structure、结构斜率slope、近月价格mon1Price】
            retPriceStruMp = dataCleanUtils.cleanToPriceStruDaily(baseInfo, tradingDay, mon1)
            if retPriceStruMp != None:
                tradingInfo['structure'] = retPriceStruMp['structure']  # 重点指标1---期限结构
                tradingInfo['slope'] = retPriceStruMp['slope']
                tradingInfo['mon1Price'] = retPriceStruMp['mon1Price']
            else:
                # print('品种' + baseInfo['productName'] + 'cleanToPriceStruDaily----异常')
                continue

            # 【基差趋势basisStru】
            # 方案1：调用基差分析【临时】
            # 缺点：主力合约切换，数据混乱
            # 缺失品种：
            # 农产品：豆一、豆二、花生、菜粕、菜油、白糖、棉纱、鸡蛋、生猪、苹果、红枣
            # 化工：乙二醇、聚丙烯、短纤
            # retBasisStruMp = dataCleanUtils.cleanToBasisDaily(baseInfo, tradingDay)
            # if retBasisStruMp != None:
            #     tradingInfo['basisStru'] = retBasisStruMp['basisStru']  # 重点指标2---基差趋势
            # else:
            #     print(baseInfo['productName'] + '，cleanToBasisDaily系统异常')
            #     continue

            # 方案2：分析跨期套利数据category和recentPrice
            # category获取日期下标
            # recentPrice获取近月价格

            # 【近远月价差spread、指定日期区间的近月价格集合】
            retSpreadMp = dataCleanUtils.cleanToSpreadDaily(baseInfo, tradingDay, mon1, mon2, dayRange, 'Y')
            if retSpreadMp != None:
                tradingInfo['mon1BasisStru'] = retSpreadMp['mon1BasisStru']
                tradingInfo['cashPriceStru'] = retSpreadMp['cashPriceStru']
                tradingInfo['mon1PriceStru'] = retSpreadMp['mon1PriceStru']
                tradingInfo['spread'] = retSpreadMp['spread']
                tradingInfo['spreadStru'] = retSpreadMp['spreadStru']
                tradingInfo['dayRange'] = dayRange
                tradingInfo['recentList'] = retSpreadMp['recentList']
                tradingInfo['cashPriceList'] = retSpreadMp['cashPriceList']
                tradingInfo['mon1'] = retSpreadMp['mon1']
                tradingInfo['mon2'] = retSpreadMp['mon2']
            else:
                # print('品种' + baseInfo['productName'] + 'cleanToSpreadDaily----异常')
                continue

            # 汇总到每日交易信息
            dataCalUtils.dailyTradingIinfoSave(tradingInfo)

        #################
        # 交易池落库
        # 策略1：
        # back结构  近月基差率>5%  盈亏比（近月基差/近远价差）>2
        # 现货价格趋势UP  近月基差趋势UP

        # 策略2：
        # contango结构  近月基差率<0%  盈亏比（月差/近月基差）>2
        # contango结构  近月基差率>0%  盈亏比（月差/近月基差）<0

        #################
        # 规则：
        # 1、先通过productCode mon1 mon2查询当前品种 是否在交易池中，
        # 2、不存在，并且满足交易条件，则直接插入
        # 【期限结构BACK,基差率>5%,盈亏比>2】
        # 3、存在，跟踪近月基差率
        # 【期限结构BACK,基差率>1%,盈亏比>0.5】则直接插入
        # 【基差率<1%】,则软删除
        dataCalUtils.dailyPoolSave(tradingDay, mon1, mon2)
        print('交易池落库END' + '\n')

        #################
        # 邮件推送
        #################
        dataCalUtils.sendEmail(mon1, mon2, tradingDay)

if __name__ == '__main__':

    setTime = "19:00"
    schedule.every().day.at(setTime).do(job)

    while True:
        print(time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time()))+" schedule.run_pending:",setTime)
        schedule.run_pending()
        print(time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time()))+" time.sleep:")
        time.sleep(1*60*10)


