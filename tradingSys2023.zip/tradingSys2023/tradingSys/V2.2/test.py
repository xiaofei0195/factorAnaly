# -*- coding:utf-8 -*-
import sys
import os
# 把当前文件所在文件夹的父文件夹路径加入到PYTHONPATH
from utils.handle import dataCleanUtils, getTempUtils, dataCalUtils, dateUtils

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from mapper.clean import baseInfoMapper as baseMp
from mapper import tradingInfoDailyMapper as tradingInfoDailyMp



def run():
    # tradingDayList = ['2023-04-28']
    # tradingDayList = ['2023-04-17', '2023-04-18', '2023-04-19', '2023-04-20','2023-04-21','2023-04-24']
    tradingDayList = dateUtils.getTradingDayList('2023-05-09', 22)
    if '2023-04-23' in tradingDayList:
        tradingDayList.remove('2023-04-23')
    print('tradingDayList:', tradingDayList)

    mon1 = '06'
    mon2 = '09'
    shiftDays = 10
    # 从基本信息库中，查询所有品种编码和名称
    baseCon = {}
    # baseCon['productCode'] = 'SA'
    retBaseList = baseMp.find_all_from_mongodb(baseCon)
    #06
    inValidMonProLlist = ['豆一','豆油','菜油','豆粕','菜粕','玉米','淀粉','棉花','油菜籽','生猪']

    for tradingDay in tradingDayList:
        print('tradingDay:' + tradingDay)
        dataCalUtils.dailyPoolSave(tradingDay, mon1, mon2)
        print('交易池落库END' + '\n')

run()