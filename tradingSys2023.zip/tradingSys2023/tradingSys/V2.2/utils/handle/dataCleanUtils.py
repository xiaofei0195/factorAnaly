# -*- coding:utf-8 -*-
import sys
import os
import requests

# 把当前文件所在文件夹的父文件夹路径加入到PYTHONPATH
from utils.handle import dateUtils

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from mapper.temp import priceStruDailyTempMapper as priceStruTempMp, basisDailyTempMapper as basisDailyTempMp, \
    warehouseDailyTempMapper as warehouseDailyTempMp, spreadDailyTempMapper as spreadDailyTempMp
from mapper.clean import priceStruDailyMapper as priceStruMp, basisDailyMapper as basisDailyMp, \
    warehouseDailyMapper as warehouseDailyMp, spreadDailyMapper as spreadDailyMp, cashPriceMapper as cashPriceMp


def cleanToPriceStruDaily(baseInfo, tradingDay, mon1):
    productCode = baseInfo['productCode']
    productName = baseInfo['productName']

    bean = {}
    bean['tradingDay'] = tradingDay
    bean['productCode'] = baseInfo['productCode']
    result = priceStruTempMp.find_one_from_mongodb(bean)
    try:
        if result != None:
            data = result['data']

            # 转实时计算
            slope = 1
            priceSet = data['todayData']

            # 获取近月价格
            for priceMp in priceSet:
                if str(mon1) in str(priceMp['instrument']):
                    mon1Price = priceMp['closePrice']
                    break

            if len(priceSet) > 3:
                price1 = float(priceSet[0]['closePrice'])
                price2 = float(priceSet[1]['closePrice'])
                price3 = float(priceSet[2]['closePrice'])
                price4 = float(priceSet[3]['closePrice'])
                # print(str(price1) + '/' + str(price2) + '/' + str(price3) + '/' + str(price4))
                if price1 == 0:
                    price1 = price2

                if price1 >= price2 and price2 >= price3 and price3 >= price4:
                    structure = 'BACK'
                elif price1 <= price2 and price2 <= price3 and price3 <= price4:
                    structure = 'CONT'
                else:
                    structure = 'OTHER'

                # 计算曲线倾斜度 （近月-远月）/近月
                slope = float(format((price1 - price3) / price1, '.2f'))

            else:
                structure = 'NG'

            # 先删除，再新增
            delCon = {}
            delCon['tradingDay'] = tradingDay
            delCon['productCode'] = productCode
            priceStruMp.delete_one_from_mongodb(delCon)

            bean = {}
            bean['productName'] = productName
            bean['productCode'] = productCode
            bean['structure'] = structure
            bean['slope'] = slope
            bean['tradingDay'] = tradingDay
            bean['mon1Price'] = mon1Price
            priceStruMp.insert_one_to_mongodb(bean)

            return bean
        else:
            '品种：' + productName + '，getTempPriceStruDaily，异常！'
    except Exception as e:
        errorMsg = '品种：' + productName + '，cleanToPriceStruDaily，异常！' + str(e)
        print(errorMsg)
        return None


def cleanToBasisDaily(baseInfo, tradingDay):
    productCode = baseInfo['productCode']
    productName = baseInfo['productName']

    tempCon = {}
    tempCon['productCode'] = baseInfo['productCode']
    result = basisDailyTempMp.find_one_from_mongodb(tempCon)
    try:
        if result != None:
            data = result['data']
            basisValue = data['basisValue']
            category = data['category']

            # 获取待查询的日期下标
            if category != None:
                tradingDayIndex = category.index(tradingDay)

                if tradingDayIndex != None:

                    # 先删除，再新增
                    delCon = {}
                    delCon['tradingDay'] = tradingDay
                    delCon['productCode'] = productCode
                    basisDailyMp.delete_one_from_mongodb(delCon)

                    bean = {}
                    bean['tradingDay'] = tradingDay
                    bean['productName'] = productName
                    bean['productCode'] = productCode

                    # 计算基差结构
                    lengh = len(category)
                    if lengh > 1:
                        lastDay = category[lengh - 1]
                        bean['lastDay'] = lastDay
                    if lengh > 20:
                        basisStru = calBasisStruV2(basisValue, tradingDayIndex)
                        bean['basisStru'] = basisStru
                    basisDailyMp.insert_one_to_mongodb(bean)
                    return bean

    except Exception as e:
        errorMsg = '品种：' + productName + '，cleanToBasisDaily，异常！' + str(e)
        print(errorMsg)
        return None


def calBasisStruV2(basisValue, index):
    #异常值处理
    basisValueNew = []
    for index, value in enumerate(basisValue):
        if value == 'NaN':
            value = basisValue[index-1]
        basisValueNew.append(value)

    subListA = basisValueNew[index - 1:index + 1]
    subListB = basisValueNew[0:index + 1]

    avgMA2 = sum(subListA) / len(subListA)
    avgMA6 = sum(subListB) / len(subListB)
    # print('avgMA2:' + str(avgMA2))
    # print('avgMA6:' + str(avgMA6))

    if avgMA2 > avgMA6:
        basisStru = 'UP'

    if avgMA2 < avgMA6:
        basisStru = 'DOWN'

    return basisStru


# 计算近月基差趋势、现货价格趋势、近月价格趋势
def calMon1BasisStru(productCode, dayRange, recentList):
    cashPriceList = []
    mon1BasisValueList = []
    for index, day in enumerate(dayRange):

        # 查询指定日期的现货价格
        queryCashPriceCon = {}
        queryCashPriceCon['tradingDay'] = day
        queryCashPriceCon['productCode'] = productCode
        retData = cashPriceMp.find_one_from_mongodb(queryCashPriceCon)

        if retData != None:
            cashPrice = retData['cashPrice']

            # 提取指定日期的近月价格
            mon1Price = recentList[index]
            # 计算近月基差
            mon1BasisValue = float(cashPrice) - float(mon1Price)
            mon1BasisValueList.append(mon1BasisValue)
            # 汇总现货价格集合
            cashPriceList.append(cashPrice)

    # 计算近月基差趋势
    mon1BasisStru = calBasisStruV2(mon1BasisValueList, len(dayRange) - 1)
    # 计算现货价格趋势
    cashPriceStru = calBasisStruV2(cashPriceList, len(dayRange) - 1)
    # 计算近月价格趋势
    mon1PriceStru = calBasisStruV2(recentList, len(dayRange) - 1)

    return mon1BasisStru, cashPriceStru, mon1PriceStru, cashPriceList


# 计算月差趋势
def calSpreadStru(productCode, dayRange, mon1, mon2):
    spreadList = []
    for index, day in enumerate(dayRange):

        # 查询指定日期的月差
        queryspreadCon = {}
        queryspreadCon['tradingDay'] = day
        queryspreadCon['productCode'] = productCode
        queryspreadCon['mon1'] = mon1
        queryspreadCon['mon2'] = mon2
        retSpreadData = spreadDailyMp.find_one_from_mongodb(queryspreadCon)

        if retSpreadData != None:
            spread = retSpreadData['spread']
            # 汇总月差集合
            spreadList.append(spread)
        # 开头历史为空，置为当前月差
        else:
            spreadList.append(spread)
    # 计算月差趋势
    spreadStru = calBasisStruV2(spreadList, len(dayRange) - 1)
    return spreadStru


# 查询近月远月价差、指定日期区间的近月价格集合
def cleanToSpreadDaily(baseInfo, tradingDay, mon1, mon2, dayRange, updFlag):
    productCode = baseInfo['productCode']
    productName = baseInfo['productName']

    basisAnyDays = len(dayRange)

    tempCon = {}
    tempCon['productCode'] = baseInfo['productCode']
    tempCon['tradingDay'] = tradingDay
    tempCon['mon1'] = mon1
    tempCon['mon2'] = mon2
    result = spreadDailyTempMp.find_one_from_mongodb(tempCon)

    dstCon = {}
    dstCon['productCode'] = productCode
    dstCon['productName'] = productName
    dstCon['tradingDay'] = result['tradingDay']
    dstCon['mon1'] = result['mon1']
    dstCon['mon2'] = result['mon2']
    dstResult = spreadDailyMp.find_one_from_mongodb(dstCon)

    try:
        if result != None and dstResult == None:

            # 获取日期集合
            data = result['data']
            dataCategory = data['dataCategory']
            category = data['category']
            recentPrice = data['recentPrice']

            codeNew = ''
            if (mon1[0] == '0'):
                codeNew = mon1.replace('0', '')
            else:
                codeNew = mon1
                # print('codeNew: ',codeNew)

            # 通过当前日期，获取指定日期下标
            dayExlYear = tradingDay[-5:]
            dataIndex = dataCategory.index(dayExlYear)

            yearData = 0
            yearSize = 0
            if int(codeNew) > 11:
                # 获取2022年价差集合
                # print('获取2022年价差集合')
                yearData = data['year2022']
            else:
                # 获取2023年价差集合
                yearData = data['year2023']
            yearSize = len(yearData)

            retDic = {}

            # 通过日期下标，获取价差
            spread = yearData[dataIndex]
            retDic['spread'] = spread

            # category获取日期下标
            try:
                index = category.index(tradingDay)
            except Exception as e:
                print('日期下标从'+tradingDay+'调整为减少1天')
                dateStrShift = dateUtils.dateStrShift(tradingDay,-1)
                index = category.index(dateStrShift)

            # recentPrice获取指定日期区间的近月价格集合
            recentList = recentPrice[index - (basisAnyDays - 1):index + 1]
            retDic['dayRange'] = dayRange
            retDic['recentList'] = recentList
            # 计算近月基差集合
            mon1BasisStru, cashPriceStru, mon1PriceStru, cashPriceList = calMon1BasisStru(productCode, dayRange,
                                                                                          recentList)
            retDic['mon1BasisStru'] = mon1BasisStru
            retDic['cashPriceStru'] = cashPriceStru
            retDic['mon1PriceStru'] = mon1PriceStru
            retDic['cashPriceList'] = cashPriceList

            retDic['productCode'] = productCode
            retDic['productName'] = productName
            retDic['tradingDay'] = result['tradingDay']
            retDic['mon1'] = result['mon1']
            retDic['mon2'] = result['mon2']
            spreadDailyMp.insert_one_to_mongodb(retDic)

            if updFlag == 'Y':
                spreadStru = calSpreadStru(productCode, dayRange, mon1, mon2)
                updCon = {}
                updCon['productCode'] = productCode
                updCon['tradingDay'] = tradingDay
                updCon['mon1'] = result['mon1']
                updCon['mon2'] = result['mon2']
                updData = {}
                updData['spreadStru'] = spreadStru
                spreadDailyMp.update_to_mongodb(updCon, updData)

        if result != None and dstResult != None:
            if updFlag == 'Y':
                spreadStru = calSpreadStru(productCode, dayRange, mon1, mon2)
                updCon = {}
                updCon['productCode'] = productCode
                updCon['tradingDay'] = tradingDay
                updCon['mon1'] = result['mon1']
                updCon['mon2'] = result['mon2']
                updData = {}
                updData['spreadStru'] = spreadStru
                spreadDailyMp.update_to_mongodb(updCon, updData)

    except Exception as e:
        errorMsg = '品种：' + productName + '，cleanToSpreadDaily，异常！' + str(e)
        print(errorMsg)
        return None

    dataCon = {}
    dataCon['productCode'] = productCode
    dataCon['tradingDay'] = result['tradingDay']
    dataCon['mon1'] = result['mon1']
    dataCon['mon2'] = result['mon2']
    dataResult = spreadDailyMp.find_one_from_mongodb(dataCon)
    return dataResult