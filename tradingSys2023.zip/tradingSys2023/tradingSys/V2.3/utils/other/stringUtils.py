def trimNum(string):
    new_string = ""
    for char in string:
        if not char.isnumeric():
            new_string += char
    return new_string
