import smtplib
from email.header import Header
from email.mime.text import MIMEText

fromAddr ='xiaofei0195@qq.com'
password = 'yfpyhcsmisoubjei'
toAddr ='xiaofei0195@qq.com'
subject = 'hello world'
content = '你好,世界'

def makeMail():
    mail = MIMEText(content, 'plain', 'utf-8')
    mail['From'] = fromAddr
    mail['To'] = Header(toAddr, 'utf-8')
    mail['Subject'] = Header(subject, 'utf-8')
    return mail

def sendMail(mail):
    server = smtplib.SMTP_SSL("smtp.qq.com")
    server.login(fromAddr, password)
    server.sendmail(fromAddr, toAddr, mail.as_string())
    server.quit()

mail = makeMail()
sendMail(mail)
print('发送邮件成功')
