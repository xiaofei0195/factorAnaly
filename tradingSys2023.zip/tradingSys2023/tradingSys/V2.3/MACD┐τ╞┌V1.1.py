# 回测配置 
'''backtest
start: 2023-05-10 08:00:00
end: 2023-05-17 21:00:00
period: 1h
basePeriod: 1h
balance: 100000
slipPoint: 2
exchanges: [{"eid":"Futures_CTP","currency":"FUTURES"}]
'''

# 导入模块
from distutils.log import Log

from fmz import *
import datetime, time
from mapper import tradingInfoDailyMapper as tradingInfoMp
from utils.other import emailUtils
from utils.other.stringUtils import trimNum

mp = 0  # 定义一个全局变量，用于控制虚拟持仓
# Instruments = "m2305&m2307|i2305&i2307"
# Instruments = "m2305&m2307" #ok
# Instruments = "ta2306&ta2309"
# Instruments = "sp2306&sp2309"
mon1 = "06"
mon2 = "09"


# 邮件附件通知结果
def notice(subject, content):
    mail = emailUtils.makeMail(subject, content)
    emailUtils.sendMail(mail)
    print('发送邮件成功')


# 程序主函数
def onTick(symbolA, symbolB, retTradingInfo):
    exchange.SetContractType(symbolA)
    recordsA = exchange.GetRecords()
    exchange.SetContractType(symbolB)
    recordsB = exchange.GetRecords()
    if not recordsA or not recordsB:
        return
    if recordsA[-1]["Time"] != recordsB[-1]["Time"]:
        return
    minL, rA, rB = min(len(recordsA), len(recordsB)), recordsA.copy(), recordsB.copy()
    rA.reverse()
    rB.reverse()
    arrDiff = []
    for i in range(minL):
        arrDiff.append(rA[i]["Close"] - rB[i]["Close"])
    arrDiff.reverse()

    if len(arrDiff) < 40:  # 如果K线列表长度太小就返回
        return
    macd = TA.MACD(arrDiff)  # 计算MACD值
    dif = macd[0][-2]  # 获取DIF的值，返回一个列表
    dea = macd[1][-2]  # 获取DEA的值，返回一个列表
    last_close = arrDiff[-1]  # 获取最新价格（卖价）

    timeStamp = recordsA[-1]['Time']
    # 转换成localtime
    time_local = time.localtime(timeStamp / 1000)
    # 转换成新的时间格式(精确到秒)
    dt = time.strftime("%Y-%m-%d %H:%M:%S", time_local)
    # print("当前时间点：",dt)
    # 当日日期
    tradingDayAvail = time.strftime("%Y-%m-%d", time_local)

    # 查询品种当日交易信息
    buyFalg = 'N'
    # queryCon = {}
    # queryCon['productCode'] = trimNum(symbolA).upper()
    # queryCon['tradingDay'] = tradingDayAvail
    # queryCon['mon1'] = mon1
    # queryCon['mon2'] = mon2
    # retTradingInfo = tradingInfoMp.find_one_from_mongodb(queryCon)
    if retTradingInfo != None:
        if retTradingInfo['mon1BasisStru'] == 'UP' and retTradingInfo['cashPriceStru'] == 'UP':
            buyFalg = 'Y'
            print(retTradingInfo['productName'], "  " + dt, "有交易信号")
    else:
        return

    global mp  # 全局变量，用于控制虚拟持仓
    if mp == 1 and dif < dea and buyFalg == 'N':
        exchange.SetContractType(symbolA)
        exchange.SetDirection("closebuy")  # 设置交易方向和类型
        exchange.Sell(recordsA[-1]["Close"], 1)

        exchange.SetContractType(symbolB)
        exchange.SetDirection("closesell")  # 设置交易方向和类型
        exchange.Buy(recordsB[-1]["Close"], 1)

        subject = '套利' + str(symbolA) + '/' + str(symbolB)
        emailMsgStr = str(dt) + '平仓 A卖B买，价差：' + str(last_close)
        print(emailMsgStr)
        mp = 0  # 设置虚拟持仓的值

        # 邮件通知
        notice(subject, emailMsgStr)

    # if mp == -1 and dif > dea:
    #     exchange.SetDirection("closesell")  # 设置交易方向和类型
    #     exchange.Buy(last_close, 1)  		# 平空单
    #     mp = 0  							# 设置虚拟持仓的值，即空仓

    if mp == 0 and dif > dea and buyFalg == 'Y':
        exchange.SetContractType(symbolA)
        exchange.SetDirection("buy")  # 设置交易方向和类型
        exchange.Buy(recordsA[-1]["Close"], 1)

        exchange.SetContractType(symbolB)
        exchange.SetDirection("sell")  # 设置交易方向和类型
        exchange.Sell(recordsB[-1]["Close"], 1)

        subject = '套利' + str(symbolA) + '/' + str(symbolB)
        emailMsgStr = str(dt) + '开仓 A买B卖，价差：' + str(last_close)
        print(emailMsgStr)
        mp = 1  # 设置虚拟持仓的值

        # 邮件通知
        notice(subject, emailMsgStr)

    # if mp == 0 and dif < dea:
    #     exchange.SetDirection("sell")  		# 设置交易方向和类型
    #     exchange.Sell(last_close - 1, 1)	# 开空单
    #     mp = -1  							# 设置虚拟持仓的值，即有空单


def main():
    # exchange.SetContractType("MA000")
    # ticker = exchange.GetTicker()
    # print("MA000 ticker:", ticker)
    #
    # timeStamp = ticker['Time']
    # # 转换成localtime
    # time_local = time.localtime(timeStamp / 1000)
    # # 转换成新的时间格式(精确到秒)
    # dt = time.strftime("%Y-%m-%d %H:%M:%S", time_local)

    # while True:
    #     status = exchange.IO("status")
    #     if status:
    #         exchange.SetContractType("MA000")
    #         ticker = exchange.GetTicker()
    #         print("MA000 ticker:", ticker)
    #         print(_D(), "已经连接CTP ！")
    #     else:
    #         print(_D(), "未连接CTP ！")

    while True:
        # 获取回测日期
        exchange.SetContractType("rb000")
        recordsA = exchange.GetRecords()
        timeStamp = recordsA[-1]['Time']
        time_local = time.localtime(timeStamp / 1000)
        tradingDayAvail = time.strftime("%Y-%m-%d", time_local)

        # 查询所有可交易品种
        queryCon = {}
        queryCon['tradingDay'] = tradingDayAvail
        queryCon['mon1'] = mon1
        queryCon['mon2'] = mon2
        queryCon['productCode'] = 'BU'
        retTradingInfoList = tradingInfoMp.find_all_from_mongodb(queryCon)
        if retTradingInfoList != None:
            for retTradingInfo in retTradingInfoList:
                productCode = retTradingInfo['productCode']
                productCodeLower = productCode.lower()
                # 近月合约
                symbolA = productCodeLower + '23' + mon1
                # 远月合约
                symbolB = productCodeLower + '23' + mon2

                onTick(symbolA, symbolB, retTradingInfo)
        Sleep(1000 * 60 * 30)


# 回测结果
task = VCtx(__doc__)  # 调用VCtx()函数
try:
    main()  # 调用策略入口函数
except Exception as e:
    print(e)
    task.Show()  # 回测结束输出图表
