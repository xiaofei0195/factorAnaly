# coding=utf-8
from __future__ import print_function, absolute_import, unicode_literals

import datetime
import time

from gm.api import *
import numpy as np
import pandas as pd

from mapper.clean import baseInfoMapper
from mapper import tradingInfoDailyMapper as tradingInfoMp, tradingPoolDailyMapper as tradingPoolMp
from mapper.clean import baseInfoMapper
import datetime

from utils.handle import dateUtils

try:
    import talib
except:
    print('请安装TA-Lib库')
    # 安装talib请看文档https://www.myquant.cn/docs/gm3_faq/154?
    sys.exit(-1)
'''
网格交易法是一种把行情的所有日间上下的波动全部囊括，不会放过任何一次行情上下波动的策略。
本策略标的为：跨期套利组合
价格中枢设定为：前一个K线布林线中轨价格，每个网格间距为上轨距离中轨的距离的1/2；每变动一次，交易一手

中下轨每触发一个网格买入
3 ---------------------------
2 ---------------------------
1 ---------------------------
0 ---------------------------
-1 ---------------------------
-2 ---------------------------
-3---------------------------
'''

def init():
    #############################################
    # 网格参数
    # 设置每变动一格，增减的数量
    volume = 1
    # 储存前一个网格所处区间，用来和最新网格所处区间作比较
    last_grid = 0
    # 记录上一次交易时网格范围的变化情况（例如从-1区到1区，记为-1,1）
    grid_change_last = [0, 0]
    # 止损条件:最大持仓
    max_volume = 5
    #############################################

    fre = '3600s'
    periods_time = 50

    #############################################
    # 品种代码【上海期货交易所】
    SHFELIST = ['PB', 'AG', 'AL', 'AU', 'BU', 'CU', 'FU', 'HC', 'NI', 'RB', 'RU', 'SN', 'SP', 'SS', 'WR', 'ZN']
    # 品种代码【郑州期货交易所】
    CZCELIST = ['MA', 'AP', 'CF', 'CJ', 'CY', 'FG', 'JR', 'LR', 'ZC', 'OI', 'PF', 'PK', 'PM', 'RI', 'RM', 'RS',
                        'SA', 'SF', 'SM', 'SR', 'TA', 'UR', 'WH']
    # 品种代码【大连期货交易所】
    DCELIST = ['B', 'J', 'JD', 'JM', 'L', 'LH', 'M', 'P', 'PG', 'PP', 'RR', 'V', 'Y', 'I', 'FB', 'EG', 'EB',
                       'CS', 'C', 'BB', 'A']
    # 品种代码【上海国际能源交易中心】
    INELIST = ['BC', 'LU', 'NR', 'SC']

    symbolList = ['CZCE.MA99']

    try:
        subscribe(symbols=symbolList[0], frequency=fre, count=periods_time, wait_group=True)
    except Exception as e:
        errorMsg = symbolList, '订阅合约异常！' + str(e)
        print(errorMsg)
        return None
    
###################################
#设置网格
###################################
def algo(context):
    # 获取价格中枢
    close_00 = data(symbol=symbolList[0], frequency=fre, count=periods_time, fields='close')['close'].values
    close_01 = data(symbol=symbolList[1], frequency=fre, count=periods_time, fields='close')['close'].values
    spread = close_00 - close_01

    # 计算Boll指标
    upper, middle, lower = talib.BBANDS(spread, timeperiod=20, nbdevup=2, nbdevdn=2, matype=0)
    center = middle[-1]
    upper = upper[-1]
    lower = lower[-1]
    # 轨道与中轨的间距
    dist = upper - center
    band = np.array([-1.5, -1, -0.5, 0, 0.5, 1, 1.5]) * dist + center

    return spread,band


if __name__ == '__main__':
    init(context)

